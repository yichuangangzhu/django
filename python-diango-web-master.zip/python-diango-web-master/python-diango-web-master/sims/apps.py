from django.apps import AppConfig


class SimsConfig(AppConfig):
    name = 'sims'
